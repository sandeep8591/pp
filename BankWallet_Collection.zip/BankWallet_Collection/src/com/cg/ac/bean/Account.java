package com.cg.ac.bean;

public class Account {
	//private String accountNo;
	private String name;
	private double balance;
	private String contactNo;
	private String accountType;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(String name, double balance, String contactNo, String accountType) {
		super();
		this.name = name;
		this.balance = balance;
		this.contactNo = contactNo;
		this.accountType = accountType;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "Account [name=" + name + ", balance=" + balance + ", contactNo="
				+ contactNo + ", accountType=" + accountType + "]\n";
	}
	
	

}
