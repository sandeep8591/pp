package com.cg.ac.util;

import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import com.cg.ac.bean.Account;

public class CollectionUtil {
	
	static Random rand = new Random();
	static Account account=null;
	static Account account1=null;
	static int randomAc;
	static HashMap<String, Account> hashAcc=null;
	static 
	{
		hashAcc= new HashMap<String, Account>();
		hashAcc.put("1322565263", new Account("Raushan", 35000, "7415417237", "Saving"));
		hashAcc.put("1322565264", new Account("Chetan", 45000, "7415417238", "Saving"));
		hashAcc.put("1322565265", new Account("Krishna", 25000, "7415417239", "Current"));
		
	}

	public static void createAccount(Account account) {
		Math.abs(randomAc=ThreadLocalRandom.current().nextInt());
		String acNo=Integer.toString(randomAc);
		
		hashAcc.put(acNo, account);
		
		System.out.println(hashAcc);
		
	}

	public static Account showBalance(String accountNo) {
		return account= hashAcc.get(accountNo);
		
	}

	public static Account deposite(String accountNo, double amount) {
		
		account= hashAcc.get(accountNo);
		
		return account=hashAcc.get(accountNo);
	}

	public static Account withDraw(String accountNo, double amount) {
		account= hashAcc.get(accountNo);
		return account=hashAcc.get(accountNo);
	}

	public static Account fundTransfer(String accountNo,String accountNo1, double amount) {
		account= hashAcc.get(accountNo);
		account1= hashAcc.get(accountNo1);
		
		amount=account.getBalance()-amount;
		account.setBalance(amount);
		amount=account.getBalance()+amount;
		account.setBalance(amount);
		return account1=hashAcc.get(accountNo);
		
	}

}
