package com.cg.ac.ui;

import java.util.Scanner;

import com.cg.ac.bean.Account;
import com.cg.ac.exception.AccountException;
import com.cg.ac.service.AccountServiceImpl;

public class AccountMain {
	
	//object for creating conncetion from service to ui
	static AccountServiceImpl acservice = null;
	
	//object for scanner
	static Scanner scan = null;
	
	static int choice;
	static Account ac=null;
	static String accountNo,accountNo1;
	static double amount;

	public static void main(String[] args) {
		acservice = new AccountServiceImpl();
		System.out.println("Welcome to HDFC Payment wallet service\n");

		do {
			System.out.println("Enter your choice:");
			System.out.println("1. Create New Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposite");
			System.out.println("4. Withdraw");
			System.out.println("5. Transfer Money");
			System.out.println("6. Print Transaction");
			System.out.println("7. Exit");
			scan = new Scanner(System.in);
			choice = scan.nextInt();
			switch (choice) {
			case 1:
				createAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
				
				deposite(accountNo,amount);
				break;
			case 4:
				withDraw(accountNo,amount);
				break;
			case 5:
				fundTransfer(accountNo,accountNo1,amount);
				break;
			case 6:

				break;
			case 7:
				System.out.println("Thank you for banking with us.");
				System.exit(0);
				break;

			default:
				break;
			}
		} while (choice != 7);
	}

	public static void createAccount() {

		System.out.println("Enter Your name:");
		String name = scan.next();
		try {
			if (acservice.validateName(name)) {

				System.out.println("Enter initial balance:");
				double amount = scan.nextDouble();
				try {
					if (true) {
						System.out.println("Enter contact no:");
						String contact = scan.next();

						try {
							if (acservice.validateContact(contact)) {
								System.out.println("Enter account type:");
								String acType = scan.next();

								try {
									if (acservice.validateAccouuntType(acType)) {

										Account account = new Account(name, amount, contact, acType);
										acservice.createAccount(account);
										System.out.println("Account created succesfully.");

									}
								} catch (Exception e) {

								}

							}

						} catch (Exception e) {

						}
					}

				}

				catch (Exception e) {

				}
			}
		} catch (Exception e) {

		}

	}
	public static void showBalance()
	{
		
		System.out.println("Enter 10 digit account no:");
		String accountNo=scan.next();
		try {
			ac=acservice.showBalance(accountNo);
			System.out.println("Your account balance is: "+ac.getBalance());
			
		} catch (Exception e) {
			
		}
		
		
	}
	
	public static void deposite(String accountNo, double amount)
	{
		try {
		System.out.println("Enter account no:");
		accountNo=scan.next();
		System.out.println("Enter amount to deposite:");
		amount=scan.nextDouble();
		ac=acservice.deposite(accountNo, amount);
		amount=amount+ac.getBalance();
		ac.setBalance(amount);	
		System.out.println("Updated balance:"+ac.getBalance());
		} catch (AccountException e) {
			
			e.printStackTrace();
		}
		
	}
	public static void withDraw(String accountNo, double amount)
	{
		try {
			System.out.println("Enter account no:");
			accountNo=scan.next();
			System.out.println("Enter amount to withdraw:");
			amount=scan.nextDouble();
			ac=acservice.withDraw(accountNo, amount);
			if(ac.getBalance()<amount)
			{
				System.out.println("Not sufficient balance:");
			}
			else {
			amount=ac.getBalance()-amount;
			ac.setBalance(amount);	
			System.out.println("Updated balance:"+ac.getBalance());
			}
			} catch (AccountException e) {
				
				e.printStackTrace();
			}
	}
	
	public static void fundTransfer(String accountNo,String accountNo1, double amount)
	{
		try {
		System.out.println("Enter sender account no:");
		accountNo=scan.next();
		System.out.println("Enter receiver account no:");
		accountNo1=scan.next();
		System.out.println("Enter amount to send:");
		amount= scan.nextDouble();
		ac=acservice.fundTransfer(accountNo,accountNo1,amount);
		System.out.println("Transaction successful.\nYour updated balance is: "+ac.getBalance());
		
		} catch (AccountException e) {
			
			e.printStackTrace();
		}
		
		
		
	}
	
}
